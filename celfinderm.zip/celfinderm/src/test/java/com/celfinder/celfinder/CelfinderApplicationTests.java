package com.celfinder.celfinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CelfinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
