package com.celfinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CelfinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(CelfinderApplication.class, args);
	}

}
